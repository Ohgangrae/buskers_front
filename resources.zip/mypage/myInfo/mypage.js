function pwCheck() {
    alert("확인되었습니다.")
    $(".myInfo-pwCheck").hide();
    $(".myInfo-update").show();
}
